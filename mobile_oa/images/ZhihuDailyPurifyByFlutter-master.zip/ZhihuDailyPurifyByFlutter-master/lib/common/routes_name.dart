class RoutesName {
  static String routesHomePage = '/HomePage';
  static String routesRegistPage = '/RegistPage';

}
