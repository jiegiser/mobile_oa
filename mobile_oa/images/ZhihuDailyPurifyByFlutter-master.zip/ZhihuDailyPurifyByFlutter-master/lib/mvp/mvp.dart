
abstract class IView<T> {
  setPresenter(T presenter);
}

abstract class IPresenter{
  init();
}
