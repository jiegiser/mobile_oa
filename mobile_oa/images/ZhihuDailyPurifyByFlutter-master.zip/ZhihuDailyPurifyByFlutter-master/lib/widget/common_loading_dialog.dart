import 'package:flutter/material.dart';

class ProgressDialog{

 static Widget buildProgressDialog() {
    return new Center(child: new CircularProgressIndicator());
  }


}
